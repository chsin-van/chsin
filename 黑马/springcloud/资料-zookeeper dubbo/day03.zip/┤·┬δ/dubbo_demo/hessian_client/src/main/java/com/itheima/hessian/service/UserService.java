package com.itheima.hessian.service;

public interface UserService {

    String sayHello(String name);

}
