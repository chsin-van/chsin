package com.itheima.dubbo;

public interface DemoService {

     String sayHello(String name);

}
