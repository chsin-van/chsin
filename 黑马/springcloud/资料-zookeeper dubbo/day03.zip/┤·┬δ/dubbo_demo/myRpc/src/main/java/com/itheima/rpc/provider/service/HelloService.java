package com.itheima.rpc.provider.service;

public interface HelloService {

    void sayHello(String msg);

    String sayHello2(String msg);


}
