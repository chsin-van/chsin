package com.itheima.spi.impl;

import com.itheima.spi.Czbk;

public class Czxy implements Czbk {

    @Override
    public void service() {
        System.out.println("不一样的大学，收获不一样的你");
    }
}
