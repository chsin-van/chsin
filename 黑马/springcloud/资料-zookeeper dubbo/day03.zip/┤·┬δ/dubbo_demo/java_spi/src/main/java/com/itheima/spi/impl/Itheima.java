package com.itheima.spi.impl;

import com.itheima.spi.Czbk;

public class Itheima implements Czbk {

    @Override
    public void service() {
        System.out.println("学it,到黑马");
    }
}
